package com.chatapp.repository;

import com.chatapp.entity.Category;
import com.chatapp.entity.RandomChatQueue;
import com.chatapp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RandomChatQueueRepository extends JpaRepository<RandomChatQueue, Long> {
    Optional<RandomChatQueue> findFirstByCategoryAndUserNotOrderByCreatedAtAsc(Category category, User user);
    void deleteByCategoryAndUser(Category category, User user);
    boolean existsByUserAndCategory(User user, Category category);
    List<RandomChatQueue> findByUser(User user);
}