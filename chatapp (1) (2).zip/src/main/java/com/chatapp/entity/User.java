package com.chatapp.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    @JsonIgnore
    private String password;

    @Column(nullable = false)
    private String nickname;

    private String profileColor;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @ManyToMany(mappedBy = "participants")
    @JsonIgnore
    private Set<ChatRoom> chatRooms = new HashSet<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (profileColor == null) {
            String[] colors = {"#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A",
                    "#98D8C8", "#F7DC6F", "#BB8FCE", "#85C1E2"};
            profileColor = colors[(int)(Math.random() * colors.length)];
        }
    }
}