package com.chatapp.controller;

import com.chatapp.entity.ChatMessage;
import com.chatapp.entity.ChatRoom;
import com.chatapp.entity.User;
import com.chatapp.service.ChatService;
import com.chatapp.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;
    private final UserService userService;

    @GetMapping("/chat")
    public String chatPage(Authentication auth, Model model) {
        User user = userService.findByUsername(auth.getName());
        List<ChatRoom> rooms = chatService.getUserRooms(user);
        List<ChatRoom> allRooms = chatService.getAllRooms();

        model.addAttribute("user", user);
        model.addAttribute("rooms", rooms);
        model.addAttribute("allRooms", allRooms);

        return "chat";
    }

    @PostMapping("/chat/room/create")
    @ResponseBody
    public ChatRoom createRoom(@RequestParam String name, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        return chatService.createRoom(name, user);
    }

    @PostMapping("/chat/room/{roomId}/join")
    @ResponseBody
    public String joinRoom(@PathVariable Long roomId, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        chatService.joinRoom(roomId, user);
        return "success";
    }

    @PostMapping("/chat/room/{roomId}/leave")
    @ResponseBody
    public String leaveRoom(@PathVariable Long roomId, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        chatService.leaveRoom(roomId, user);
        return "success";
    }

    @GetMapping("/chat/room/{roomId}/messages")
    @ResponseBody
    public List<ChatMessage> getRoomMessages(@PathVariable Long roomId) {
        ChatRoom room = chatService.getRoom(roomId);
        return chatService.getRoomMessages(room);
    }
}