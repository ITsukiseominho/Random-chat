package com.chatapp.controller;

import com.chatapp.entity.Category;
import com.chatapp.entity.ChatRoom;
import com.chatapp.entity.User;
import com.chatapp.service.RandomChatService;
import com.chatapp.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class RandomChatController {

    private final RandomChatService randomChatService;
    private final UserService userService;

    @GetMapping("/random")
    public String randomChatPage(Authentication auth, Model model) {
        User user = userService.findByUsername(auth.getName());
        List<Category> categories = randomChatService.getAllCategories();

        model.addAttribute("user", user);
        model.addAttribute("categories", categories);

        return "random";
    }

    @PostMapping("/random/match")
    @ResponseBody
    public Map<String, Object> findMatch(@RequestParam Long categoryId, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        ChatRoom room = randomChatService.findOrCreateMatch(user, categoryId);

        Map<String, Object> response = new HashMap<>();
        if (room != null) {
            response.put("status", "matched");
            response.put("roomId", room.getId());
            response.put("roomName", room.getName());
        } else {
            response.put("status", "waiting");
        }

        return response;
    }

    @PostMapping("/random/cancel")
    @ResponseBody
    public String cancelQueue(@RequestParam Long categoryId, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        randomChatService.cancelQueue(user, categoryId);
        return "success";
    }

    @GetMapping("/random/status")
    @ResponseBody
    public Map<String, Object> checkStatus(@RequestParam Long categoryId, Authentication auth) {
        User user = userService.findByUsername(auth.getName());
        boolean inQueue = randomChatService.isInQueue(user, categoryId);

        Map<String, Object> response = new HashMap<>();
        response.put("inQueue", inQueue);
        return response;
    }
}