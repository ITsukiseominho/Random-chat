package com.chatapp.controller;

import com.chatapp.dto.ChatMessageDTO;
import com.chatapp.entity.ChatMessage;
import com.chatapp.entity.ChatRoom;
import com.chatapp.entity.User;
import com.chatapp.service.ChatService;
import com.chatapp.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.time.format.DateTimeFormatter;

@Controller
@RequiredArgsConstructor
public class WebSocketChatController {

    private final SimpMessagingTemplate messagingTemplate;
    private final ChatService chatService;
    private final UserService userService;

    @MessageMapping("/chat.sendMessage")
    public void sendMessage(@Payload ChatMessageDTO messageDTO, Principal principal) {
        User sender = userService.findByUsername(principal.getName());
        ChatRoom room = chatService.getRoom(messageDTO.getRoomId());

        ChatMessage savedMessage = chatService.saveMessage(
                room, sender, messageDTO.getContent(), ChatMessage.MessageType.CHAT
        );

        messageDTO.setSender(sender.getNickname());
        messageDTO.setSenderColor(sender.getProfileColor());
        messageDTO.setType(ChatMessage.MessageType.CHAT);
        messageDTO.setTimestamp(savedMessage.getSentAt()
                .format(DateTimeFormatter.ofPattern("HH:mm")));

        messagingTemplate.convertAndSend(
                "/topic/room/" + messageDTO.getRoomId(), messageDTO
        );
    }

    @MessageMapping("/chat.addUser")
    public void addUser(@Payload ChatMessageDTO messageDTO,
                        SimpMessageHeaderAccessor headerAccessor,
                        Principal principal) {
        User user = userService.findByUsername(principal.getName());
        ChatRoom room = chatService.getRoom(messageDTO.getRoomId());

        headerAccessor.getSessionAttributes().put("username", user.getUsername());
        headerAccessor.getSessionAttributes().put("roomId", messageDTO.getRoomId());

        messageDTO.setSender(user.getNickname());
        messageDTO.setSenderColor(user.getProfileColor());
        messageDTO.setType(ChatMessage.MessageType.JOIN);
        messageDTO.setContent(user.getNickname() + "님이 입장했습니다.");

        messagingTemplate.convertAndSend(
                "/topic/room/" + messageDTO.getRoomId(), messageDTO
        );
    }
}