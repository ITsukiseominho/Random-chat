package com.chatapp.service;

import com.chatapp.entity.*;
import com.chatapp.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RandomChatService {

    private final RandomChatQueueRepository queueRepository;
    private final CategoryRepository categoryRepository;
    private final ChatRoomRepository chatRoomRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Transactional
    public ChatRoom findOrCreateMatch(User user, Long categoryId) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));

        // 이미 대기 중인지 확인
        if (queueRepository.existsByUserAndCategory(user, category)) {
            return null;
        }

        // 매칭 가능한 유저 찾기
        Optional<RandomChatQueue> matchQueue = queueRepository
                .findFirstByCategoryAndUserNotOrderByCreatedAtAsc(category, user);

        if (matchQueue.isPresent()) {
            // 매칭 성공
            User matchedUser = matchQueue.get().getUser();

            // 채팅방 생성
            ChatRoom room = new ChatRoom();
            room.setName(category.getName() + " 랜덤채팅");
            room.setCreator(user);
            room.setCategory(category);
            room.setIsRandomChat(true);
            room.getParticipants().add(user);
            room.getParticipants().add(matchedUser);

            ChatRoom savedRoom = chatRoomRepository.save(room);

            // 큐에서 제거
            queueRepository.delete(matchQueue.get());

            // 대기 중이던 유저에게 WebSocket으로 매칭 알림
            Map<String, Object> notification = new HashMap<>();
            notification.put("status", "matched");
            notification.put("roomId", savedRoom.getId());
            notification.put("roomName", savedRoom.getName());
            messagingTemplate.convertAndSendToUser(
                    matchedUser.getUsername(),
                    "/queue/match",
                    notification
            );

            return savedRoom;
        } else {
            // 대기열에 추가
            RandomChatQueue queue = new RandomChatQueue();
            queue.setUser(user);
            queue.setCategory(category);
            queueRepository.save(queue);

            return null;
        }
    }

    @Transactional
    public void cancelQueue(User user, Long categoryId) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        queueRepository.deleteByCategoryAndUser(category, user);
    }

    public boolean isInQueue(User user, Long categoryId) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        return queueRepository.existsByUserAndCategory(user, category);
    }

    @Transactional
    public void initializeCategories() {
        if (categoryRepository.count() == 0) {
            String[][] categories = {
                    {"게임", "🎮", "#FF6B6B"},
                    {"음악", "🎵", "#4ECDC4"},
                    {"영화", "🎬", "#45B7D1"},
                    {"운동", "⚽", "#FFA07A"},
                    {"요리", "🍳", "#98D8C8"},
                    {"여행", "✈️", "#F7DC6F"},
                    {"독서", "📚", "#BB8FCE"},
                    {"프로그래밍", "💻", "#85C1E2"}
            };

            for (String[] cat : categories) {
                Category category = new Category();
                category.setName(cat[0]);
                category.setIcon(cat[1]);
                category.setColor(cat[2]);
                categoryRepository.save(category);
            }
        }
    }
}