package com.chatapp.service;

import com.chatapp.entity.ChatMessage;
import com.chatapp.entity.ChatRoom;
import com.chatapp.entity.User;
import com.chatapp.repository.ChatMessageRepository;
import com.chatapp.repository.ChatRoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final ChatRoomRepository chatRoomRepository;
    private final ChatMessageRepository chatMessageRepository;

    @Transactional
    public ChatRoom createRoom(String name, User creator) {
        ChatRoom room = new ChatRoom();
        room.setName(name);
        room.setCreator(creator);
        room.getParticipants().add(creator);
        return chatRoomRepository.save(room);
    }

    @Transactional
    public void joinRoom(Long roomId, User user) {
        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));
        room.getParticipants().add(user);
        chatRoomRepository.save(room);
    }

    @Transactional
    public void leaveRoom(Long roomId, User user) {
        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));
        room.getParticipants().remove(user);
        chatRoomRepository.save(room);
    }

    @Transactional
    public ChatMessage saveMessage(ChatRoom room, User sender, String content, ChatMessage.MessageType type) {
        ChatMessage message = new ChatMessage();
        message.setChatRoom(room);
        message.setSender(sender);
        message.setContent(content);
        message.setType(type);
        return chatMessageRepository.save(message);
    }

    public List<ChatRoom> getUserRooms(User user) {
        return chatRoomRepository.findByParticipant(user);
    }

    public List<ChatRoom> getAllRooms() {
        return chatRoomRepository.findAll();
    }

    public ChatRoom getRoom(Long roomId) {
        return chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));
    }

    public List<ChatMessage> getRoomMessages(ChatRoom room) {
        return chatMessageRepository.findByChatRoomOrderBySentAtAsc(room);
    }
}