package com.chatapp.dto;

import com.chatapp.entity.ChatMessage;
import lombok.Data;

@Data
public class ChatMessageDTO {
    private String content;
    private String sender;
    private String senderColor;
    private Long roomId;
    private ChatMessage.MessageType type;
    private String timestamp;
}